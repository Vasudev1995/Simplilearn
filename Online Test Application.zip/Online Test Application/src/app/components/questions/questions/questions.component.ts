import { Component, OnInit } from '@angular/core';
import { interval } from 'rxjs';
import { QuestionsService } from 'src/app/services/questions.service';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {

  public name: string;
  public points: number;
  public currentQuestion: number;
  public counter: number = 15;
  public correctAnswers: number = 0;
  public incorrectAnswers: number = 0;
  public attemptedQuestions: number = 0;
  public questions: any = [];
  public quizCompleted: boolean = false;
  interval$: any;


  constructor(private questionService: QuestionsService) { }

  ngOnInit(): void {
    this.name = localStorage.getItem('name');
    this.points = 0;
    this.currentQuestion = 0;
    this.startCounter();
    this.questionService.getQuestion().subscribe((ques) => {
      this.questions = ques.question;
      console.log(this.questions);
    });
  }

  answer(currentQuestion: number, options: any) {

    console.log(currentQuestion, options);
    
    this.resetCounter();

    if (currentQuestion + 1 == this.questions.length) {
      this.quizCompleted = true;
      
    }
    if (options.correct) {
      console.log("correct answer");
      this.points += 3;
      this.correctAnswers++;
      this.attemptedQuestions++;
    }
    else {
      console.log("wrong answer");
      this.points -= 1;
      this.incorrectAnswers++;
      this.attemptedQuestions++;
    }

    this.currentQuestion++;/*setTimeout(() => {
      this.currentQuestion++
    }, 1000
    );*/
  }
  startCounter() {
    this.interval$ = interval(1000).subscribe(val => {
      this.counter--;
      if (this.counter == 0) {
        this.currentQuestion++;
        this.counter = 15;
      }
      if (this.currentQuestion  == this.questions.length) {
        this.quizCompleted = true;
      }

    })
  }
  resetCounter(){
    this.counter=15;
  }
}
